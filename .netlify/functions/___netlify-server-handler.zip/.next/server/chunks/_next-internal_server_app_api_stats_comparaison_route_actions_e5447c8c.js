module.exports=[18912,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_stats_comparaison_route_actions_e5447c8c.js.map