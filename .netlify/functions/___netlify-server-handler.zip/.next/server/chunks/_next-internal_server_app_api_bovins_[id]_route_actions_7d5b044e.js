module.exports=[74804,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bovins_%5Bid%5D_route_actions_7d5b044e.js.map