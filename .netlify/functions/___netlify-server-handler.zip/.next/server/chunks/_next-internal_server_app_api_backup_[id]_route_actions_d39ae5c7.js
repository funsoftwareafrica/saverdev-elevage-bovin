module.exports=[88898,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_backup_%5Bid%5D_route_actions_d39ae5c7.js.map