module.exports=[28235,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_alertes_route_actions_5fbfc341.js.map