module.exports=[68,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_soins_a-venir_route_actions_6c425b56.js.map