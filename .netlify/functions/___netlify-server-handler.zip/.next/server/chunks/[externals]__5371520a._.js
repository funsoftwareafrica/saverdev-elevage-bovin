module.exports=[21517,(r,t,e)=>{t.exports=r.x("http",()=>require("http"))},24836,(r,t,e)=>{t.exports=r.x("https",()=>require("https"))},92509,(r,t,e)=>{t.exports=r.x("url",()=>require("url"))}];

//# sourceMappingURL=%5Bexternals%5D__5371520a._.js.map