module.exports=[42146,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ventes_%5Bid%5D_route_actions_9b6e3575.js.map