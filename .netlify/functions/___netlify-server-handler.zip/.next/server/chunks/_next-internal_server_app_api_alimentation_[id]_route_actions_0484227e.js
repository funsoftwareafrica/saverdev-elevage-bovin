module.exports=[64029,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_alimentation_%5Bid%5D_route_actions_0484227e.js.map