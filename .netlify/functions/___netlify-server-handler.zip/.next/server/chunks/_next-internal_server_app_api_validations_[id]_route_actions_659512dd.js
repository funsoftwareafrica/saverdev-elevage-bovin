module.exports=[60522,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_validations_%5Bid%5D_route_actions_659512dd.js.map