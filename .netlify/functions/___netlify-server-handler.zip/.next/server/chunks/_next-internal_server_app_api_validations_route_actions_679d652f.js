module.exports=[14830,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_validations_route_actions_679d652f.js.map