module.exports=[67812,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_ventes_route_actions_32287532.js.map