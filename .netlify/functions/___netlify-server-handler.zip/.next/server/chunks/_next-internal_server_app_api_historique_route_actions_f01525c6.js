module.exports=[71136,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_historique_route_actions_f01525c6.js.map