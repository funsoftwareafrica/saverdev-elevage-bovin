module.exports=[17584,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_budget_route_actions_4cc16167.js.map