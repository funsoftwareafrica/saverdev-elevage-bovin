module.exports=[25612,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_soins_%5Bid%5D_route_actions_1a922f12.js.map