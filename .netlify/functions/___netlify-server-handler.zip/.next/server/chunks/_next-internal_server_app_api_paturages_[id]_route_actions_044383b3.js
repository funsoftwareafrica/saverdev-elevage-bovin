module.exports=[13534,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paturages_%5Bid%5D_route_actions_044383b3.js.map