module.exports=[13528,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bovins_%5Bid%5D_tags_route_actions_511b548f.js.map