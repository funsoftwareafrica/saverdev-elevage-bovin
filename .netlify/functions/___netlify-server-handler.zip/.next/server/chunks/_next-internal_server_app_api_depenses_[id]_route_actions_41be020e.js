module.exports=[34992,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_depenses_%5Bid%5D_route_actions_41be020e.js.map