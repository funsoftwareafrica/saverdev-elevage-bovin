module.exports=[81333,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_depenses_route_actions_1ae69e86.js.map