module.exports=[73377,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_parametres_route_actions_1f85cca4.js.map