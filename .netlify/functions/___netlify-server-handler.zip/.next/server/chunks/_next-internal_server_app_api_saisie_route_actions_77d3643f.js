module.exports=[23367,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_saisie_route_actions_77d3643f.js.map