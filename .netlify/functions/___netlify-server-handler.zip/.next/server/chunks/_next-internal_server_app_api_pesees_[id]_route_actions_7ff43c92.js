module.exports=[96474,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_pesees_%5Bid%5D_route_actions_7ff43c92.js.map