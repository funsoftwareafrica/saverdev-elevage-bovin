module.exports=[30080,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_alimentation_route_actions_279ac2f2.js.map