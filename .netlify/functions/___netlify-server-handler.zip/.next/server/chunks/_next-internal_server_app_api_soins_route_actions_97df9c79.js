module.exports=[77295,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_soins_route_actions_97df9c79.js.map