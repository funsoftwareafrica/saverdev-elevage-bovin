module.exports=[38888,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_paturages_route_actions_fc32e53d.js.map