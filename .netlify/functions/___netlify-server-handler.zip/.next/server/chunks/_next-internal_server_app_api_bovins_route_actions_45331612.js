module.exports=[23064,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bovins_route_actions_45331612.js.map