module.exports=[80114,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_tresorerie_route_actions_152659b2.js.map