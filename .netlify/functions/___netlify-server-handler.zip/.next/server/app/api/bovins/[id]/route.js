var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bovins/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0b459606._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_bovins_[id]_route_actions_7d5b044e.js")
R.m(7206)
module.exports=R.m(7206).exports
