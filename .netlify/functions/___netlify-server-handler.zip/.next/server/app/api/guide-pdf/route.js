var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/guide-pdf/route.js")
R.c("server/chunks/[root-of-the-server]__e8ac2a72._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_guide-pdf_route_actions_db32bffb.js")
R.m(13726)
module.exports=R.m(13726).exports
