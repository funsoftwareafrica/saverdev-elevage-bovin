var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/notifications/check/route.js")
R.c("server/chunks/[root-of-the-server]__9db08782._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_notifications_check_route_actions_66f6e730.js")
R.m(72928)
module.exports=R.m(72928).exports
