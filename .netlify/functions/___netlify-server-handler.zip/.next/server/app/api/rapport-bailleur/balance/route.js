var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rapport-bailleur/balance/route.js")
R.c("server/chunks/[root-of-the-server]__0d24aa9f._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_rapport-bailleur_balance_route_actions_8b9a5f2e.js")
R.m(89592)
module.exports=R.m(89592).exports
