var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/paturages/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__725009b1._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_paturages_[id]_route_actions_044383b3.js")
R.m(13299)
module.exports=R.m(13299).exports
