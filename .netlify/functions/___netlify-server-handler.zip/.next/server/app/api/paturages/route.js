var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/paturages/route.js")
R.c("server/chunks/[root-of-the-server]__33c3bdf9._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_paturages_route_actions_fc32e53d.js")
R.m(96787)
module.exports=R.m(96787).exports
