var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/alimentation/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2736210c._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_alimentation_[id]_route_actions_0484227e.js")
R.m(70494)
module.exports=R.m(70494).exports
