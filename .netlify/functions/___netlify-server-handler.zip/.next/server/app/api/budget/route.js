var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/budget/route.js")
R.c("server/chunks/[root-of-the-server]__ef2802d0._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_budget_route_actions_4cc16167.js")
R.m(68830)
module.exports=R.m(68830).exports
