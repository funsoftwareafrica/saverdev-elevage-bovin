var R=require("../../chunks/[turbopack]_runtime.js")("server/app/api/route.js")
R.c("server/chunks/[root-of-the-server]__97d50c9b._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/_next-internal_server_app_api_route_actions_dcc5d538.js")
R.m(91070)
module.exports=R.m(91070).exports
