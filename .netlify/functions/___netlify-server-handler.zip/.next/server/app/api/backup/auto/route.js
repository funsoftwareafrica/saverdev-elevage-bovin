var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/backup/auto/route.js")
R.c("server/chunks/[root-of-the-server]__af4a5538._.js")
R.c("server/chunks/[root-of-the-server]__24b50c38._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_backup_auto_route_actions_f4cd726f.js")
R.m(13206)
module.exports=R.m(13206).exports
