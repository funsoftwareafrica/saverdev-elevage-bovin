var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/backup/[id]/download/route.js")
R.c("server/chunks/[root-of-the-server]__47e56665._.js")
R.c("server/chunks/[root-of-the-server]__24b50c38._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_backup_[id]_download_route_actions_75c5493c.js")
R.m(78205)
module.exports=R.m(78205).exports
