var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/backup/route.js")
R.c("server/chunks/[root-of-the-server]__6267c62d._.js")
R.c("server/chunks/[root-of-the-server]__24b50c38._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_backup_route_actions_69ec7f9d.js")
R.m(14249)
module.exports=R.m(14249).exports
