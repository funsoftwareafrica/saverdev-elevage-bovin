var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pesees/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__4a0f9f85._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_pesees_[id]_route_actions_7ff43c92.js")
R.m(34998)
module.exports=R.m(34998).exports
