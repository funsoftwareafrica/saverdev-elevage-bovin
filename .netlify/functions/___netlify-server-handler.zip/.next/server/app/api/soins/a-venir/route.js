var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/soins/a-venir/route.js")
R.c("server/chunks/[root-of-the-server]__0b3c9f87._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_soins_a-venir_route_actions_6c425b56.js")
R.m(65089)
module.exports=R.m(65089).exports
