var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/soins/route.js")
R.c("server/chunks/[root-of-the-server]__511dc6a7._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_soins_route_actions_97df9c79.js")
R.m(80529)
module.exports=R.m(80529).exports
