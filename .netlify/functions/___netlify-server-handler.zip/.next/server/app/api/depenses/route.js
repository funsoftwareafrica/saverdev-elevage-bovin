var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/depenses/route.js")
R.c("server/chunks/[root-of-the-server]__787197bc._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_depenses_route_actions_1ae69e86.js")
R.m(90041)
module.exports=R.m(90041).exports
