var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/mois-cloture/route.js")
R.c("server/chunks/[root-of-the-server]__ccd9e3e6._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_mois-cloture_route_actions_9934422a.js")
R.m(15988)
module.exports=R.m(15988).exports
