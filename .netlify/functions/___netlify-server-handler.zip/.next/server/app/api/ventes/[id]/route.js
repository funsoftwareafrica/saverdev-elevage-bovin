var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/ventes/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__7a9c4e7e._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_ventes_[id]_route_actions_9b6e3575.js")
R.m(98722)
module.exports=R.m(98722).exports
