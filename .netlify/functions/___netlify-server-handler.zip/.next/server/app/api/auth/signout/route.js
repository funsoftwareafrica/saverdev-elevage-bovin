var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signout/route.js")
R.c("server/chunks/[root-of-the-server]__760a28a3._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signout_route_actions_0273b13a.js")
R.m(31878)
module.exports=R.m(31878).exports
