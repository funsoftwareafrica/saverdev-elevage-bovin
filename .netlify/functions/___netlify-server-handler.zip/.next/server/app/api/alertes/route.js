var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/alertes/route.js")
R.c("server/chunks/[root-of-the-server]__33eed337._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/_next-internal_server_app_api_alertes_route_actions_5fbfc341.js")
R.m(74674)
module.exports=R.m(74674).exports
