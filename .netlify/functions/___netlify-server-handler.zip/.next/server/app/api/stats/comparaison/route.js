var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/comparaison/route.js")
R.c("server/chunks/[root-of-the-server]__39915b66._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_stats_comparaison_route_actions_e5447c8c.js")
R.m(2003)
module.exports=R.m(2003).exports
