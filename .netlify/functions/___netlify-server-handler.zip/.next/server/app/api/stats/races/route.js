var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/stats/races/route.js")
R.c("server/chunks/[root-of-the-server]__19a9def6._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_stats_races_route_actions_d37c84de.js")
R.m(71751)
module.exports=R.m(71751).exports
