var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/parametres/route.js")
R.c("server/chunks/[root-of-the-server]__809368ab._.js")
R.c("server/chunks/[root-of-the-server]__0dd017b7._.js")
R.c("server/chunks/node_modules_next_dist_79f1aee4._.js")
R.c("server/chunks/[root-of-the-server]__ea845f9f._.js")
R.c("server/chunks/node_modules_next_f2da0d3e._.js")
R.c("server/chunks/_next-internal_server_app_api_parametres_route_actions_1f85cca4.js")
R.m(89038)
module.exports=R.m(89038).exports
